package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.border.LineBorder;

import controller.Features;

/**
 * The Class ImageView represents JFrame view for image operations
 * functionality. It implements IImageView interface and offers set of methods
 * to interact with controller.
 */
public class ImageView extends JFrame implements IImageView {

  /** The img label. */
  private JLabel imgLabel = new JLabel();

  /** The file picker load. */
  private JFilePicker filePickerLoad;

  /** The file picker save. */
  private JFilePicker filePickerSave;

  /** The load button. */
  private JButton loadButton;

  /** The save button. */
  private JButton saveButton;

  /** The blur button. */
  private JButton blurButton;

  /** The sharpen button. */
  private JButton sharpenButton;

  /** The sepia button. */
  private JButton sepiaButton;

  /** The greyscale button. */
  private JButton greyscaleButton;

  /** The edgedetection button. */
  private JButton edgedetectionButton;

  /** The dithering button. */
  private JButton ditheringButton;

  /** The mosaicing button. */
  private JButton mosaicingButton;

  /** The equalization button. */
  private JButton equalizationButton;

  /** The redeye button. */
  private JButton redeyeButton;

  /** The generate image. */
  private JButton generateImage;

  /** The reset button. */
  private JButton resetButton;

  /** The exit button. */
  private JButton exitButton;

  /** The capture rect. */
  private Rectangle captureRect;

  /** The scroller. */
  private JScrollPane scroller;

  /**
   * Instantiates a new image view.
   */
  public ImageView() {

    // Sets up the view and adds the components

    super("PhotoShop");

    JPanel imagePanel;

    Container mainContainer;

    mainContainer = this.getContentPane();
    mainContainer.setLayout(new BorderLayout(8, 6));
    mainContainer.setBackground(Color.cyan);
    this.getRootPane().setBorder(BorderFactory.createMatteBorder(4, 4, 4, 4, Color.DARK_GRAY));

    imagePanel = new JPanel();
    imagePanel.setLayout(new BorderLayout(8, 8));
    imagePanel.setBorder(new LineBorder(Color.WHITE));
    imagePanel.setBackground(Color.red);

    JPanel browsePanel = new JPanel();
    browsePanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 5));
    browsePanel.setBorder(new LineBorder(Color.WHITE));
    browsePanel.setBackground(Color.gray);

    JPanel optionPanel = new JPanel();
    optionPanel.setLayout(new FlowLayout(5, 5, 5));
    optionPanel.setBorder(new LineBorder(Color.WHITE, 3));
    optionPanel.setBackground(Color.LIGHT_GRAY);

    JPanel filterPanel = new JPanel();
    filterPanel.setLayout(new GridLayout(11, 1, 5, 5));
    filterPanel.setBackground(Color.LIGHT_GRAY);

    // set up a file picker component
    this.filePickerLoad = new JFilePicker();
    this.filePickerLoad.setMode(JFilePicker.MODE_OPEN);
    this.filePickerLoad.addFileTypeFilter(".jpg", "JPEG Images");
    this.filePickerLoad.addFileTypeFilter(".png", "PNG Images");

    this.filePickerSave = new JFilePicker();
    this.filePickerSave.setMode(JFilePicker.MODE_SAVE);
    this.filePickerSave.addFileTypeFilter(".jpg", "JPEG Images");
    this.filePickerSave.addFileTypeFilter(".png", "PNG Images");

    this.blurButton = new JButton("Blur");
    this.sharpenButton = new JButton("Sharpen");
    this.greyscaleButton = new JButton("Greyscale");
    this.sepiaButton = new JButton("Sepia");
    this.edgedetectionButton = new JButton("Edge Detection");
    this.ditheringButton = new JButton("Dithering");
    this.mosaicingButton = new JButton("Mosaicing");
    this.equalizationButton = new JButton("Equalization");
    this.redeyeButton = new JButton("Red Eye Removal");
    this.generateImage = new JButton("Generate Images");
    this.loadButton = new JButton("Load");
    this.saveButton = new JButton("Save");
    this.resetButton = new JButton("Reset");
    this.exitButton = new JButton("Exit");
    // add the component to the frame
    browsePanel.add(filePickerLoad);
    browsePanel.add(loadButton);
    browsePanel.add(filePickerSave);
    browsePanel.add(saveButton);
    browsePanel.add(Box.createHorizontalStrut(250));
    browsePanel.add(exitButton);

    filterPanel.add(blurButton);
    filterPanel.add(sharpenButton);
    filterPanel.add(greyscaleButton);
    filterPanel.add(sepiaButton);
    filterPanel.add(edgedetectionButton);
    filterPanel.add(ditheringButton);
    filterPanel.add(mosaicingButton);
    filterPanel.add(equalizationButton);
    filterPanel.add(redeyeButton);
    filterPanel.add(generateImage);
    filterPanel.add(resetButton);

    optionPanel.add(filterPanel);

    mainContainer.add(browsePanel, BorderLayout.NORTH);

    mainContainer.add(optionPanel, BorderLayout.WEST);

    scroller = new JScrollPane(imgLabel);
    imagePanel.add(scroller, BorderLayout.CENTER);

    mainContainer.add(imagePanel, BorderLayout.CENTER);

    // JScrollPane scroller = new JScrollPane(imgLabel);
    // this.add(scroller, BorderLayout.CENTER);
    // this.add(imgLabel, SwingConstants.CENTER);

    // mainContainer.add(scroller, BorderLayout.CENTER);

    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setExtendedState(JFrame.MAXIMIZED_BOTH);
    this.setUndecorated(true);

    // this.setLocationRelativeTo(null);
    this.pack();
    this.setVisible(true);

  }

  /**
   * Sets the features.
   *
   * @param f the new features
   */
  @Override
  public void setFeatures(Features f) {

    this.loadButton.addActionListener(l -> f.loadImage(filePickerLoad.getSelectedFilePath()));
    this.saveButton.addActionListener(l -> f.saveImage(filePickerSave.getSelectedFilePath()));
    this.blurButton.addActionListener(l -> f.blurImage());
    this.sharpenButton.addActionListener(l -> f.sharpenImage());
    this.greyscaleButton.addActionListener(l -> f.greyscaleImage());
    this.sepiaButton.addActionListener(l -> f.sepiaImage());
    this.edgedetectionButton.addActionListener(l -> f.edgedetectionImage());
    this.ditheringButton.addActionListener(l -> f.ditheringImage());
    this.mosaicingButton.addActionListener(l -> {
      f.mosaicingImage(
          Integer.parseInt(JOptionPane.showInputDialog("Enter the Number of Seeds:")));
    });
    this.equalizationButton.addActionListener(l -> f.equalizationImage());
    this.redeyeButton.addActionListener(l -> f.redeyeRemovalImage(captureRect));
    this.generateImage.addActionListener(l -> f.generateImage());
    this.exitButton.addActionListener(l -> f.exitProgram());
    this.resetButton.addActionListener(l -> f.loadImage(filePickerLoad.getSelectedFilePath()));

  }

  /**
   * Sets the image.
   *
   * @param file the new image
   */
  @Override
  public void setImage(BufferedImage file) {
    // imgLabel = new JLabel(new ImageIcon(file), SwingConstants.CENTER);

    final BufferedImage screen = file;

    SwingUtilities.invokeLater(new Runnable() {
      public void run() {
        dragImage(screen);
      }
    });

    // this.add(imgLabel, BorderLayout.CENTER);

  }

  /**
   * Drag image.
   *
   * @param screen the screen
   */
  private void dragImage(BufferedImage screen) {
    final BufferedImage screenCopy = new BufferedImage(screen.getWidth(), screen.getHeight(),
        screen.getType());
    imgLabel.setIcon(new ImageIcon(screenCopy));

    scroller
        .setPreferredSize(new Dimension((int) (screen.getWidth()), (int) (screen.getHeight())));
    // mainContainer.add(scroller);
    // this.add(imgLabel, BorderLayout.CENTER);
    // this.add(scroller, BorderLayout.CENTER);

    repaint(screen, screenCopy);
    this.pack();
    imgLabel.repaint();

    imgLabel.addMouseMotionListener(new MouseMotionAdapter() {

      Point start = new Point();

      @Override
      public void mouseMoved(MouseEvent me) {

        start = me.getPoint();

        repaint(screen, screenCopy);
        imgLabel.repaint();

      }

      @Override
      public void mouseDragged(MouseEvent me) {
        Point end = me.getPoint();
        captureRect = new Rectangle(start, new Dimension(end.x - start.x, end.y - start.y));
        repaint(screen, screenCopy);
        imgLabel.repaint();
      }
    });

    // JOptionPane.showMessageDialog(null, imgLabel);
  }

  /**
   * Display error message.
   *
   * @param errorMessage the error message
   */
  // Open a popup that contains the error message passed
  @Override
  public void displayErrorMessage(String errorMessage) {

    JOptionPane.showMessageDialog(this, errorMessage);

  }

  /**
   * Repaint.
   *
   * @param orig the orig
   * @param copy the copy
   */
  private void repaint(BufferedImage orig, BufferedImage copy) {
    Graphics2D g = copy.createGraphics();
    g.drawImage(orig, 0, 0, null);
    if (captureRect != null) {
      g.setColor(Color.RED);
      g.draw(captureRect);
      g.setColor(new Color(255, 255, 255, 150));
      g.fill(captureRect);
    }
    g.dispose();
  }

  /**
   * Update script status.
   *
   * @param msg the msg
   */
  @Override
  public void updateScriptStatus(String msg) {
    JOptionPane.showMessageDialog(this, msg);
  }

}
